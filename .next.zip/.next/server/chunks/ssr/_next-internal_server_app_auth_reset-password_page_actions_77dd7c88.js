module.exports=[39872,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_auth_reset-password_page_actions_77dd7c88.js.map