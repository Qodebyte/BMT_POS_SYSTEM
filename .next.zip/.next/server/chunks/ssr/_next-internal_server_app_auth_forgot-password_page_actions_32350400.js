module.exports=[26344,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_auth_forgot-password_page_actions_32350400.js.map