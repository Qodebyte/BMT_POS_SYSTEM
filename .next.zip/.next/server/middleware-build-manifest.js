globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/a6dad97d9634a72d.js"
  ],
  "lowPriorityFiles": [],
  "rootMainFiles": [
    "static/chunks/0e1d4a177458003f.js",
    "static/chunks/8cd1659f713c9b17.js",
    "static/chunks/ad4cf95c856c591c.js",
    "static/chunks/b390b677733cccaa.js",
    "static/chunks/turbopack-7ddb991737ca9649.js"
  ]
};
globalThis.__BUILD_MANIFEST.lowPriorityFiles = [
"/static/" + process.env.__NEXT_BUILD_ID + "/_buildManifest.js",
"/static/" + process.env.__NEXT_BUILD_ID + "/_ssgManifest.js"
];